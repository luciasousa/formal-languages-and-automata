abstract public class Value
{
   public Type type()
   {
      assert false;
      return null;
   }

   public void setIntValue(int val)
   {
      assert false;
   }

   public void setRealValue(double val)
   {
      assert false;
   }

   public void setBoolValue(boolean val)
   {
      assert false;
   }

   public int intValue()
   {
      assert false;
      return 0;
   }

   public double realValue()
   {
      assert false;
      return 0;
   }
   public boolean boolValue()
   {
      assert false;
      return false;
   }

}

