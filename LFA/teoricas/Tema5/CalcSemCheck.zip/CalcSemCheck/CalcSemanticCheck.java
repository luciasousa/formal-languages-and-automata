import static java.lang.System.*;
import org.antlr.v4.runtime.tree.ParseTreeProperty;
import org.antlr.v4.runtime.ParserRuleContext;
import java.util.*;

public class CalcSemanticCheck extends CalcBaseVisitor<Boolean> { // visitor callbacks return true if no semantic error was detected!
   public ParseTreeProperty<Type> types() {
      return types;
   }

   public Map<String,Symbol<Double>> symbolTable() {
      return symbolTable;
   }

	@Override public Boolean visitDeclaration(CalcParser.DeclarationContext ctx) {
      // first visit type:
      boolean res = visit(ctx.type()); // in this example is always true
      if (res) {
         types.put(ctx.idList(), types.get(ctx.type()));
         res = visit(ctx.idList());
      }
      return res;
   }

	protected boolean declareID(String id, ParserRuleContext ctx) {
      boolean res = true;
      if (symbolTable.containsKey(id)) {
         ErrorHandling.printError(ctx, "variable "+id+" already exists!");
         res = false;
      }
      else {
         Type t = types.get(ctx);
         Symbol<Double> s = new VariableSymbol<Double>(id, t);
         symbolTable.put(id, s);
      }
      return res;
   }

	@Override public Boolean visitIdListWithComma(CalcParser.IdListWithCommaContext ctx) {
      boolean res = declareID(ctx.ID().getText(), ctx);
      types.put(ctx.other, types.get(ctx));
      return visit(ctx.other) && res;
   }

	@Override public Boolean visitSimpleId(CalcParser.SimpleIdContext ctx) {
      return declareID(ctx.ID().getText(), ctx);
   }

   @Override public Boolean visitIntegerType(CalcParser.IntegerTypeContext ctx) {
      types.put(ctx, integerType);
      return true;
   }

   @Override public Boolean visitRealType(CalcParser.RealTypeContext ctx) {
      types.put(ctx, realType);
      return true;
   }

   @Override public Boolean visitAssignment(CalcParser.AssignmentContext ctx) {
      boolean res = visit(ctx.expr());
      String v = ctx.ID().getText();
      if (!symbolTable.containsKey(v)) {
         ErrorHandling.printError(ctx, "variable "+v+" not declared!");
         res = false;
      }
      else if (res && !types.get(ctx.expr()).subtype(symbolTable.get(v).type())) {
         ErrorHandling.printError(ctx, types.get(ctx.expr()).name()+" expression is not assignable to variable "+v+" "+symbolTable.get(v).type().name()+" type!");
         res = false;
      }
      return res;
   }

   protected Type getBinaryOperationType(CalcParser.ExprContext e1, CalcParser.ExprContext e2) {
      Type res;
      Type te1 = types.get(e1);
      Type te2 = types.get(e2);
      if (te1.equals(te2))
         res = te1;
      else
         res = realType;
      return res;
   }

   @Override public Boolean visitExprMultDiv(CalcParser.ExprMultDivContext ctx) {
      boolean res = visit(ctx.e1) && visit(ctx.e2);
      if (res) {
         types.put(ctx, getBinaryOperationType(ctx.e1, ctx.e2));
         switch(ctx.op.getText())
         {
            case "//":
            case "\\":
               if (!types.get(ctx.e1).subtype(integerType)) {
                  ErrorHandling.printError(ctx, "type expression "+ctx.e1.getText()+" is not integer!");
                  res = false;
               }
               else if (!types.get(ctx.e2).subtype(integerType)) {
                  ErrorHandling.printError(ctx, "type expression "+ctx.e2.getText()+" is not integer!");
                  res = false;
               }
               break;
         }
      }
      return res;
   }

   @Override public Boolean visitExprAddSub(CalcParser.ExprAddSubContext ctx) {
      boolean res = visit(ctx.e1) && visit(ctx.e2);
      if (res)
         types.put(ctx, getBinaryOperationType(ctx.e1, ctx.e2));
      return res;
   }

   @Override public Boolean visitExprInt(CalcParser.ExprIntContext ctx) {
      types.put(ctx, integerType);
      return true;
   }

   @Override public Boolean visitExprReal(CalcParser.ExprRealContext ctx) {
      types.put(ctx, realType);
      return true;
   }

   @Override public Boolean visitExprID(CalcParser.ExprIDContext ctx) {
      boolean res = true;
      String v = ctx.ID().getText();
      if (!symbolTable.containsKey(v)) {
         ErrorHandling.printError(ctx, "variable "+v+" not declared!");
         res = false;
      }
      else
         types.put(ctx, symbolTable.get(v).type());
      return res;
   }

	@Override public Boolean visitExprParen(CalcParser.ExprParenContext ctx) {
      boolean res = visit(ctx.e);
      if (res)
         types.put(ctx, types.get(ctx.e));
      return res;
   }

   protected ParseTreeProperty<Type> types = new ParseTreeProperty<>();
   protected Map<String,Symbol<Double>> symbolTable = new HashMap<>();
   protected static final Type realType = new RealType();
   protected static final Type integerType = new IntegerType();
}

