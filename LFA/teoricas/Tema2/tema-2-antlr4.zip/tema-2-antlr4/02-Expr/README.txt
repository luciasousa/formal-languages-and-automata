- First install ANTLR-v4 and  scripts in file antlr4-bin.zip

- Compile with:

   ./build

- Test with:

   ./test prog1.txt

- Clean garbage with:

   ./clean
