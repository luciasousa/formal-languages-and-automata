import static java.lang.System.*;
import java.util.Scanner;

public class A
{
   static final Scanner sc = new Scanner(System.in);

   public static void main(String[] args)
   {

   }
}

