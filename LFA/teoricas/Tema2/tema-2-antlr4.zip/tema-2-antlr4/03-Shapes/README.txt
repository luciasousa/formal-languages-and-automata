- First install ANTLR-v4 and  scripts in file antlr4-bin.zip

- ShapesMain.java created with command:

  antlr4-main -l MyListener -l MyListener2 -v MyVisitor.java Shapes main

- Compile with:

   ./build

- Test with:

   ./run prog1.txt

- Clean garbage with:

   ./clean
