- First install ANTLR-v4 and  scripts in file antlr4-bin.zip

- HelloMain.java created with command:

  antlr4-main -l MyListener Hello r

- Compile with:

   ./build

- Test with:

   ./run prog1.txt
   ./run err1.txt

- Clean garbage with:

   ./clean
